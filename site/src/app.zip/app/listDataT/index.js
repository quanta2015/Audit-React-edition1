import React from 'react'
import { inject } from 'mobx-react'
import { Input, Form, Button, Icon,Tag, Table, Spin, Divider, Result, Modal, message, Skeleton } from "antd";

import Highlighter from 'react-highlight-words';

import './index.less'
import {API_SERVER} from 'constant/apis'


@inject('userStore')
class listData extends React.Component {
	constructor(props) {
		super(props)

    this.state = {
      cur: 0,
      list: [],
    }
	}

    getColumnSearchProps = dataIndex => ({
    filterDropdown: ({ setSelectedKeys, selectedKeys, confirm, clearFilters }) => (
      <div style={{ padding: 8 }}>
        <Input
          ref={node => {
            this.searchInput = node;
          }}
          placeholder={`Search ${dataIndex}`}
          value={selectedKeys[0]}
          onChange={e => setSelectedKeys(e.target.value ? [e.target.value] : [])}
          onPressEnter={() => this.handleSearch(selectedKeys, confirm)}
          style={{ width: 188, marginBottom: 8, display: 'block' }}
        />
        <Button
          type="primary"
          onClick={() => this.handleSearch(selectedKeys, confirm)}
          icon="search"
          size="small"
          style={{ width: 90, marginRight: 8 }}
        >
          Search
        </Button>
        <Button onClick={() => this.handleReset(clearFilters)} size="small" style={{ width: 90 }}>
          Reset
        </Button>
      </div>
    ),
    filterIcon: filtered => (
      <Icon type="search" style={{ color: filtered ? '#1890ff' : undefined }} />
    ),
    onFilter: (value, record) =>
      record[dataIndex]
        .toString()
        .toLowerCase()
        .includes(value.toLowerCase()),
    onFilterDropdownVisibleChange: visible => {
      if (visible) {
        setTimeout(() => this.searchInput.select());
      }
    },
    render: text => (
      <Highlighter
        highlightStyle={{ backgroundColor: '#ffc069', padding: 0 }}
        searchWords={[this.state.searchText]}
        autoEscape
        textToHighlight={text.toString()}
      />
    ),
  });

  handleSearch = (selectedKeys, confirm) => {
    confirm();
    this.setState({ searchText: selectedKeys[0] });
  };

  handleReset = clearFilters => {
    clearFilters();
    this.setState({ searchText: '' });
  };

  async componentDidMount() {

    let cur = this.props.userStore.currUser
    if ((typeof(cur) === 'undefined')||(cur === null)) {
      this.props.history.push("/")
    }else{
      this.setState({ loading: true })
      let r = await this.props.userStore.getProjList()
      console.log(r)
      this.setState({ loading: false, list: r})
    }
  }




	render() {

    let { list } = this.state

    const columns = [{
        title: '申请时间',
        dataIndex: 'apdt',
        width: '160px',
        defaultSortOrder: 'descend',
        sorter: (a, b) => a.apdt - b.apdt,
        render: d => <span className="m-date">{ DT.formatApdt(d,true) }</span>
      },{
        title: '项目名称',
        dataIndex: 'addr',
        key: 'addr',
        ...this.getColumnSearchProps('addr'),
      },{
        title: '状态',
        dataIndex: 'stat',
        width: '120px',
        filters: getStatFilter(),
        onFilter: (value, record) => record.stat_name  === value,
        render: d =>
          <Tag color={formatStat(d)[1]}>
            {formatStat(d)[0]}
          </Tag>
      },{
        title: '功能',
        key: 'action',
        width: '200px',
        render: (text, record, index) => (
          (record.stat!==-1) &&
          <div>
            <Button type="primary" icon="appstore" onClick={this.doDetail.bind(this,record)}>详情</Button>
            <Button type="danger"  icon="close" onClick={this.doStop.bind(this,record)}>终止</Button>
          </div>
        ),
      },
    ];


		return (
      <div className="g-list">
        <div className="m-list">
          <Table size='small' dataSource={list} columns={columns}/>

        </div>
      </div>
		)
	}
}

export default listData
