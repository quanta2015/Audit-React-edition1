import userStore from './User'

export default {
  userStore,
}
