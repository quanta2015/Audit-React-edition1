/*
 Navicat Premium Data Transfer

 Source Server         : local
 Source Server Type    : MySQL
 Source Server Version : 50709
 Source Host           : localhost:3306
 Source Schema         : audit

 Target Server Type    : MySQL
 Target Server Version : 50709
 File Encoding         : 65001

 Date: 13/08/2020 09:27:30
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usr` varchar(10) DEFAULT NULL,
  `pwd` varchar(10) DEFAULT NULL,
  `role` varchar(10) DEFAULT NULL,
  `mark` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
BEGIN;
INSERT INTO `user` VALUES (1, 's01', 'qwerty', '0', 1);
INSERT INTO `user` VALUES (2, 's02', 'asdfgh', '0', 2);
INSERT INTO `user` VALUES (3, 's03', 'zxcvbn', '0', 3);
INSERT INTO `user` VALUES (4, 's04', 'poiuyt', '0', 4);
INSERT INTO `user` VALUES (5, 's05', 'lkjhgf', '0', 5);
INSERT INTO `user` VALUES (6, 's06', 'mnbvcx', '0', 6);
INSERT INTO `user` VALUES (7, 's07', 'qazxsw', '0', 7);
INSERT INTO `user` VALUES (8, 's08', 'edcvfr', '0', 8);
INSERT INTO `user` VALUES (9, 's09', 'tgbnhy', '0', 9);
INSERT INTO `user` VALUES (10, 's10', 'ujmkio', '0', 10);
INSERT INTO `user` VALUES (11, 't01', 'mnbvcx', '1', NULL);
INSERT INTO `user` VALUES (12, 't02', 'iuytre', '1', NULL);
INSERT INTO `user` VALUES (13, 'admin', '123456', '2', NULL);
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
