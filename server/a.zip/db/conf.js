let conf = {
  host: 'localhost',
  port: 3306,
  database: 'audit',
  user:     'audit',
  password: '123456',
  multipleStatements: true,
  secret: 'moocsystem',
};


module.exports = conf;